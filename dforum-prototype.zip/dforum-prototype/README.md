# DForum Prototype (TON + User Governance + AI Enforcement)

This repo is a **prototype scaffold** for a decentralized, Twitter-like forum with:

- **Two publish paths**
  - **Sponsored Publish**: AI baseline screening + moderation receipt + eligible for default distribution + subsidized storage
  - **Self Publish**: user-paid storage, no default distribution (direct link only)
- **Governance-controlled policy** (on-chain state drives off-chain AI execution)
- **World ID (optional) human-weighting** via *off-chain verification receipt + on-chain nullifier registry*
- **Reporting vs Complaints**
  - *Report*: non-adversarial risk signal (no direct payout)
  - *Complaint*: adversarial claim with stake + potential slashing
- **Anti-duplication / anti-astroturfing** (exact/near/semantic clustering)
- **Tipping** with automatic split (e.g., 80% creator / 20% platform pool)

> Note: This prototype focuses on **interfaces, schemas, and service boundaries**. It is not production-hardened.

## Folder layout

- `apps/mobile_flutter/` Flutter app skeleton
- `services/gateway/` Publish gateway (AI screening + receipt issuing)
- `services/indexer/` Indexer API (feed/search/thread) with receipt-gated distribution
- `services/moderation/` Moderation policy runner + duplicate detector
- `packages/protocol/` Shared types, schemas, signatures
- `contracts/` TON contract placeholders (policy registry, tip splitter, stake vault)
- `docs/` Architecture, threat model, governance constitution v0.1

## Quick start (dev)

Requirements:
- Node.js 20+
- pnpm

```bash
pnpm -C services/gateway install
pnpm -C services/gateway dev

pnpm -C services/indexer install
pnpm -C services/indexer dev
```

## Next steps

1. Implement TON integration (TON Connect on mobile; contract calls from backend)
2. Add World ID receipt verifier service
3. Add storage adapter(s) (TON Storage gateway + third-party)
4. Add basic moderation model adapter (text + URL + image)
5. Add indexer storage (Postgres + vector DB for semantic clustering)

