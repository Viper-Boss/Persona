import Fastify from 'fastify';
import {
  PostSchema,
  ModerationReceiptSchema,
  PolicySchema,
} from '@dforum/protocol';

const app = Fastify({ logger: true });

// In a real system, these are loaded from TON PolicyRegistry.
let currentPolicy = {
  policy_id: 'demo-policy-hash',
  version: '0.1.0',
  l0: {
    hard_prohibited: [
      'human_trafficking',
      'hard_drugs_sale',
      'csam',
      'explicit_fraud',
      'terrorism'
    ]
  },
  l1: {
    soft_nsfw: {
      publish_requirement: { world_id_required: true, stake_required: false },
      distribution: { home_feed_weight: 0.2, recommend_allowed: false, search_allowed: true },
      labeling: { nsfw_tag: true, blur_preview: true }
    }
  }
};

app.get('/policy', async () => ({ policy: currentPolicy }));

/** Sponsored publish: run baseline screening, issue receipt, broadcast to indexers. */
app.post('/publish/sponsored', async (req, reply) => {
  const post = PostSchema.parse(req.body);

  // TODO: verify author signature; fetch content (or accept inline) and run model checks.
  // TODO: duplicate detection (exact/near/semantic).

  // Demo: always pass.
  const receipt = {
    post_id: post.post_id,
    policy_id: currentPolicy.policy_id,
    policy_version: currentPolicy.version,
    model_version: 'demo-model@0.0.1',
    result: 'pass',
    risk_labels: [],
    issued_at: Math.floor(Date.now() / 1000),
    auditor_pubkey: 'demo-auditor',
    auditor_sig: 'demo-sig'
  };

  ModerationReceiptSchema.parse(receipt);

  // TODO: write content to storage via adapter (TON Storage) with subsidy.
  // TODO: broadcast {post, receipt} to indexers.

  return reply.code(200).send({ ok: true, receipt });
});

/** Self publish: no screening, no receipt, user paid storage. */
app.post('/publish/self', async (req, reply) => {
  const post = PostSchema.parse(req.body);
  // TODO: verify author signature.
  // TODO: accept a storage ref produced by the client or third-party gateway.
  return reply.code(200).send({ ok: true, indexed: false, post_id: post.post_id });
});

app.listen({ port: 8787, host: '0.0.0.0' });
