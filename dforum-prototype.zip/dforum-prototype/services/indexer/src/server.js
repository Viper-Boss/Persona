import Fastify from 'fastify';
import { PostSchema, ModerationReceiptSchema } from '@dforum/protocol';

const app = Fastify({ logger: true });

// In-memory store for prototype.
const posts = new Map(); // post_id -> post
const receipts = new Map(); // post_id -> receipt

app.post('/ingest', async (req, reply) => {
  const { post, receipt } = req.body ?? {};
  const p = PostSchema.parse(post);
  const r = ModerationReceiptSchema.parse(receipt);

  if (r.result !== 'pass') {
    return reply.code(202).send({ ok: true, indexed: false, reason: r.result });
  }

  posts.set(p.post_id, p);
  receipts.set(p.post_id, r);
  return reply.code(200).send({ ok: true, indexed: true });
});

app.get('/feed/home', async () => {
  // Prototype: return newest 50 posts (receipt-pass only).
  const all = Array.from(posts.values()).sort((a, b) => b.created_at - a.created_at).slice(0, 50);
  return { items: all };
});

app.get('/post/:id', async (req, reply) => {
  const id = req.params.id;
  const post = posts.get(id);
  if (!post) return reply.code(404).send({ error: 'not_found' });
  return { post, receipt: receipts.get(id) };
});

app.listen({ port: 8790, host: '0.0.0.0' });
