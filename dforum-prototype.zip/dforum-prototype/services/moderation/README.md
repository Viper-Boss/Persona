# Moderation Service (Prototype)

This service is a placeholder for:

- Policy-driven checks (L0 platform hard rules, L1 community rules)
- Model adapters (text/image/url)
- Duplicate detection stack:
  1. Exact fingerprint
  2. Near-duplicate (SimHash/LSH)
  3. Semantic clustering (embeddings)

In production, the gateway would call this service and then sign receipts.
