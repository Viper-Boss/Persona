import 'package:flutter/material.dart';

void main() {
  runApp(const DForumApp());
}

class DForumApp extends StatelessWidget {
  const DForumApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DForum Prototype',
      theme: ThemeData(useMaterial3: true),
      home: const HomeFeedScreen(),
    );
  }
}

class HomeFeedScreen extends StatefulWidget {
  const HomeFeedScreen({super.key});

  @override
  State<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends State<HomeFeedScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: ListView.builder(
        itemCount: 20,
        itemBuilder: (context, i) => ListTile(
          title: Text('Post #$i'),
          subtitle: const Text('Receipt-pass content would appear here.'),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const ComposeScreen()),
          );
        },
        child: const Icon(Icons.edit),
      ),
    );
  }
}

class ComposeScreen extends StatelessWidget {
  const ComposeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Compose')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const TextField(
              maxLines: 5,
              decoration: InputDecoration(
                labelText: 'What\'s happening?',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: const Text('Sponsored Publish (AI + Free Storage)'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {},
                    child: const Text('Self Publish (User Paid, No Default Distribution)'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Text(
              'TODO: integrate TON Connect, signature, and gateway calls.',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
