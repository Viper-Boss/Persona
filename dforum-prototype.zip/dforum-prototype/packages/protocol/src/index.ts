import { z } from "zod";

/**
 * Core immutable Post object.
 * Content body/media are referenced by content_ref (e.g., TON Storage bag id).
 */
export const PostSchema = z.object({
  post_id: z.string(),            // hash
  author: z.string(),             // TON address
  created_at: z.number(),         // unix seconds
  content_ref: z.string(),        // storage pointer
  reply_to: z.string().optional(),
  quote_to: z.string().optional(),
  tags: z.array(z.string()).default([]),
  attachments_ref: z.array(z.string()).default([]),
  sig: z.string()                 // signature over canonical payload
});
export type Post = z.infer<typeof PostSchema>;

/** Moderation policy parameters are machine-readable and governance-controlled. */
export const PolicySchema = z.object({
  policy_id: z.string(),          // hash of the policy document
  version: z.string(),
  l0: z.object({
    hard_prohibited: z.array(z.string())
  }),
  l1: z.record(z.string(), z.object({
    publish_requirement: z.object({
      world_id_required: z.boolean().default(false),
      stake_required: z.boolean().default(false)
    }).default({}),
    distribution: z.object({
      home_feed_weight: z.number().min(0).max(1).default(1),
      recommend_allowed: z.boolean().default(true),
      search_allowed: z.boolean().default(true)
    }).default({}),
    labeling: z.object({
      nsfw_tag: z.boolean().default(false),
      blur_preview: z.boolean().default(false)
    }).default({})
  }))
});
export type Policy = z.infer<typeof PolicySchema>;

/** Moderation receipt signed by an auditor/gateway. */
export const ModerationReceiptSchema = z.object({
  post_id: z.string(),
  policy_id: z.string(),
  policy_version: z.string(),
  model_version: z.string(),
  result: z.enum(["pass", "fail", "review"]),
  risk_labels: z.array(z.string()).default([]),
  issued_at: z.number(),
  auditor_pubkey: z.string(),
  auditor_sig: z.string()
});
export type ModerationReceipt = z.infer<typeof ModerationReceiptSchema>;

/** Report (non-adversarial signal). */
export const ReportSchema = z.object({
  report_id: z.string(),
  reporter: z.string(),
  post_id: z.string(),
  reason: z.enum(["fraud", "crime", "hate", "spam", "duplicate", "nsfw", "other"]),
  created_at: z.number(),
  details: z.string().optional(),
  sig: z.string()
});
export type Report = z.infer<typeof ReportSchema>;

/** Complaint (adversarial claim with stake). */
export const ComplaintSchema = z.object({
  complaint_id: z.string(),
  complainant: z.string(),
  target: z.enum(["post", "user", "review"]),
  target_id: z.string(),
  reason: z.string(),
  stake_amount: z.string(),
  created_at: z.number(),
  sig: z.string()
});
export type Complaint = z.infer<typeof ComplaintSchema>;

/** Tip (creator monetization). */
export const TipSchema = z.object({
  tip_id: z.string(),
  from: z.string(),
  to: z.string(),
  post_id: z.string().optional(),
  amount: z.string(),
  created_at: z.number(),
  split_bps_creator: z.number().int().min(0).max(10000).default(8000),
  split_bps_platform: z.number().int().min(0).max(10000).default(2000),
  sig: z.string()
}).refine(v => v.split_bps_creator + v.split_bps_platform === 10000, {
  message: "split must sum to 10000 bps"
});
export type Tip = z.infer<typeof TipSchema>;
