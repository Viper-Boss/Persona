import { z } from "zod";

export const ContentRefSchema = z.object({
  scheme: z.enum(["ton-storage", "ipfs", "https"]),
  ref: z.string().min(1),
  mime: z.string().min(1).optional(),
  sizeBytes: z.number().int().nonnegative().optional(),
  hash: z.string().min(16).optional() // content hash (sha256/blake3)
});

export const PostSchema = z.object({
  postId: z.string().min(16), // content hash of canonical post envelope
  author: z.string().min(1),  // TON address
  createdAt: z.string().datetime(),
  replyTo: z.string().min(16).optional(),
  quoteTo: z.string().min(16).optional(),
  tags: z.array(z.string()).default([]),
  textRef: ContentRefSchema,          // points to canonicalized text payload
  attachments: z.array(ContentRefSchema).default([]),
  client: z.object({
    name: z.string().optional(),
    version: z.string().optional()
  }).optional(),
  sig: z.string().min(10) // author signature over canonical envelope
});

export const ModerationReceiptSchema = z.object({
  postId: z.string().min(16),
  policyVersion: z.string().min(1),
  modelVersion: z.string().min(1),
  result: z.enum(["pass", "fail", "review"]),
  labels: z.array(z.string()).default([]),
  riskScore: z.number().min(0).max(1).optional(),
  issuedAt: z.string().datetime(),
  auditorPubkey: z.string().min(10),
  auditorSig: z.string().min(10)
});

export const GovernancePolicySchema = z.object({
  version: z.string(),
  updatedAt: z.string().datetime(),
  // L0: non-negotiable
  l0: z.object({
    disallowedLabels: z.array(z.string()).default([
      "human_trafficking",
      "hard_drugs_trade",
      "child_sexual_content",
      "explicit_fraud",
      "terrorism"
    ]),
    blockSponsoredOnFail: z.boolean().default(true)
  }),
  // L1: community-tunable
  l1: z.object({
    classes: z.record(
      z.string(),
      z.object({
        homeFeedWeight: z.number().min(0).max(1).default(1),
        recommendAllowed: z.boolean().default(true),
        searchAllowed: z.boolean().default(true),
        requireWorldIdToPublishSponsored: z.boolean().default(false),
        blurPreview: z.boolean().default(false)
      })
    ).default({})
  }),
  // anti-duplication
  dedupe: z.object({
    exactWindowMinutes: z.number().int().positive().default(60),
    nearSimhashHamming: z.number().int().min(0).max(64).default(6),
    semanticWindowHours: z.number().int().positive().default(72),
    semanticThreshold: z.number().min(0).max(1).default(0.90)
  })
});

export type Post = z.infer<typeof PostSchema>;
export type ModerationReceipt = z.infer<typeof ModerationReceiptSchema>;
export type GovernancePolicy = z.infer<typeof GovernancePolicySchema>;
