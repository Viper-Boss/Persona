# Governance Constitution v0.1 (Draft)

## Scope
This document defines governance layers and how on-chain policy controls off-chain AI enforcement.

## Layers

### L0: Non-negotiable platform prohibitions (not votable)
- Human trafficking
- Hard drug sales
- CSAM
- Explicit fraud/scams
- Terrorism / credible incitement to violence

### L1: Community-governed boundaries (votable)
Examples: soft NSFW, borderline violent imagery, controversial speech categories.
Decisions are expressed as **policy parameters**, not as per-post deletions.

### L2: Personal preferences
Client-side filters (blur, hide, downrank) that do not affect global distribution policy.

## Change control
- Voting windows: every 30/90 days (configurable)
- Activation delay: 7 days after passing
- Parameter change caps: limit delta per vote to reduce oscillation

## Distribution rules
- Default distribution requires a valid ModerationReceipt with result=pass.
- Self-published content remains accessible via direct reference but is not indexed by default.
