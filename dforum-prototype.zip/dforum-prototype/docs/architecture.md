# Architecture Overview

## Principles

- **Data immutability, distribution governance**: content may be stored immutably, but *default distribution* requires a valid moderation receipt.
- **Minimum platform enforcement (L0)**: platform-enforced prohibitions for clear violent crime, human trafficking, hard drugs, child sexual content, and explicit fraud.
- **Community governance (L1)**: community votes on borderline categories (e.g., soft NSFW) and their distribution parameters.
- **Personal preferences (L2)**: client-side filtering preferences.

## Components

### Mobile App
- Wallet connection (TON Connect)
- Post creation/signing
- Sponsored vs Self publish selection
- Feed/search via indexer selection (multi-indexer)

### Publish Gateway
- Receives signed posts
- Runs baseline AI screening and duplicate checks
- If pass: uploads content via storage adapter, issues **ModerationReceipt** (signed)
- Broadcasts to indexers

### Indexer
- Ingests posts + receipts
- Only indexes **receipt-passing posts** by default
- Computes event/story clusters and performs deduplicated ranking
- Exposes API for feed/search/thread

### Moderation Service
- Policy engine driven by **on-chain policy state**
- Executes model calls (text/image/url) and produces labels/scores
- Emits receipts (or delegates signing to gateway)

### TON Contracts (placeholders)
- `PolicyRegistry`: stores current governance policy version hash + parameters
- `NullifierRegistry`: prevents World ID proof re-use (one-person-one-action)
- `TipSplitter`: splits tips to creator and platform pool
- `StakeVault`: manages complaint stakes and slashing

## Two publish paths

### Sponsored Publish
1. User signs Post
2. Gateway screens (L0 + L1 policy) and checks duplicates
3. If pass: storage write is subsidized
4. Receipt is issued and broadcast
5. Indexers include in default distribution

### Self Publish
1. User signs Post
2. User uploads directly (or via a third-party gateway)
3. No receipt
4. Not indexed by default; accessible via direct link or opt-in clients

