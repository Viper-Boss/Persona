# TON Contracts (Placeholders)

This folder contains placeholders for TON contracts:

- `PolicyRegistry`: stores current policy hash/params (governance-controlled)
- `NullifierRegistry`: World ID nullifier registry to prevent proof replay
- `TipSplitter`: splits tips (e.g., 80/20 creator/platform pool)
- `StakeVault`: complaint stake, slashing, and payout logic

Implementation can be done in **Tact** or **FunC**.
